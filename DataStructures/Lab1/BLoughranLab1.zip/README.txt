This is a simple simulation of people entering and exiting a 
narrow elevator

The input and output file names are supplied by the user 
at runtime as command line arguments, as per the project 
specifications. The main() class is elevatorSimulator.java
You can run the code with the following command:

elevatorSimulator.java /path/to/input.txt /path/to/output.txt

/path/to/input.txt = file path of the input file
/path/to/output.txt = file path of the output file

Java 10.0.1 was used in creation of this lab, but any recent version 
should be OK to run
