public class javaUsingIntelliJ {
    public static void main(String[] args) {

        // Initial vertical spaceing before MY JAVA
        System.out.println("\n\n\n");

        // -------------------- Print "MY JAVA" -------------------------------

        System.out.println("MM   MM Y    Y      J    A     V     V     A    ");
        System.out.println("M MMM M  Y  Y       J   A A     V   V     A A   ");
        System.out.println("M  M  M    Y    J   J  AAAAA     V V     AAAAA  ");
        System.out.println("M     M    Y     J J  A     A     V     A     A ");

        // -------------------- END Print "MY JAVA" ---------------------------

        // Vertical spacing between MY JAVA and USING
        System.out.println("\n\n");

        // -------------------- Print "USING" ---------------------------------

        System.out.println("U     U  SSSSS  IIIIIII  N     N  GGGG   ");
        System.out.println("U     U  S         I     NN    N  G      ");
        System.out.println("U     U   SS       I     N  N  N  G GGGG ");
        System.out.println(" U   U       S     I     N   N N  G    G ");
        System.out.println("  UUU     SSSS   IIIII   N    NN  GGGGGG ");

        // -------------------- END Print "USING" -----------------------------

        //Vertical spacing between MY JAVA and INTELLIJ
        System.out.println("\n\n");

        // -------------------- Print "INTELLIJ"-------------------------------

        System.out.println("IIIIIII  N     N  TTTTTTT  EEEEEEE  L        L        IIIIIII  JJJJJJJ ");
        System.out.println("   I     NN    N     T     E        L        L           I        J    ");
        System.out.println("   I     N  N  N     T     EEEEE    L        L           I        J    ");
        System.out.println("   I     N   N N     T     E        L        L           I     J  J    ");
        System.out.println(" IIIII   N    NN     T     EEEEEEE  LLLLLLL  LLLLLLL   IIIII    JJ     ");

        // -------------------- END Print "INTELLIJ ----------------------------------------------------------------------

        System.out.println("\n\n");

    }
}
