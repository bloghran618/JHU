/*
 / Drawable interface designates a drawable object
 */

public interface Drawable
{
    void drawObject();
}
