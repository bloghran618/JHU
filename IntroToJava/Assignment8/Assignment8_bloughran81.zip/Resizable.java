/*
 / Rotatable interface designates a rotatable object
 */

public interface Resizable
{
    void resizeObject();
}
