/*
 / Rotatable interface designates a rotatable object
 */

public interface Rotatable
{
    void rotateObject();
}
