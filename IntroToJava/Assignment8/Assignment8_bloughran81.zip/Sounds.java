/*
 / Drawable interface designates a drawable object
 */

public interface Sounds
{
    void playSound();
}
